package com.example.beans;

public class Student {
	   String name;
	    int age;
	    String regNumber;
	    // to create getter and setter class , right click on java class , choose source then >> generate getter and setter class
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public int getAge() {
			return age;
		}
		public void setAge(int age) {
			this.age = age;
		}
		public String getRegNumber() {
			return regNumber;
		}
		public void setRegNumber(String regNumber) {
			this.regNumber = regNumber;
		}
}
