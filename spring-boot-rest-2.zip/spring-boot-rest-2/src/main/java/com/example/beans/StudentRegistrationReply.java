package com.example.beans;

public class StudentRegistrationReply {
	 String name;
	    int age;
	    String registrationNumber;
	    String registrationStatus;
	    

	    public String getName() {
	    return name;
	    }
	    public void setName(String name) {
	    this.name = name;
	    }
	    public int getAge() {
	    return age;
	    }
	    public void setAge(int age) {
	    this.age = age;
	    }
	    public String getRegistrationNumber() {
	    return registrationNumber;
	    }
	    public void setRegistrationNumber(String registrationNumber) {
	    this.registrationNumber = registrationNumber;
	    }
	    public String getRegistrationStatus() {
	    return registrationStatus;
	    }
	    public void setRegistrationStatus(String registrationStatus) {
	    this.registrationStatus = registrationStatus;
	    }

}
