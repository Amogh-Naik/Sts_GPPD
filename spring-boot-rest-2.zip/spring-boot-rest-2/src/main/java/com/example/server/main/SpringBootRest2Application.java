package com.example.server.main;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication(scanBasePackages = {"com.example"})
public class SpringBootRest2Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootRest2Application.class, args);
	}

}
/*
- This is a Spring Boot main class. 
- A Spring Boot REST application loads through this class. 
- We can also see that this class is created with the annotation @SpringBootApplication . 
- The annotation @SpringBootApplication is equivalent to using @Configuration, @EnableAutoConfiguration
- the main class is always annotated with all three of these important annotations.

- we are going to modify the @SpringBootApplication (given below in the Java class) with a component path. 
- Without that, the application cannot find out the controller classes(rest-controller).
*/