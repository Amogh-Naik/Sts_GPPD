package com.example.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.PathVariable;

import com.example.beans.*;

@Controller
public class StudentDeleteController_delete_mthd {
	@RequestMapping(method = RequestMethod.DELETE, value="/delete/student/{regdNum}")

	@ResponseBody
	public String deleteStudentRecord(@PathVariable("regdNum") String regdNum) {
	System.out.println("In deleteStudentRecord");   
	    return StudentRegistration.getInstance().deleteStudent(regdNum);
	}
}
