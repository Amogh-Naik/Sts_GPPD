package com.example.controllers;

import java.util.List;


import org.springframework.stereotype.Controller;
//import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RequestMapping;

import com.example.beans.*;

@Controller
public class StudentRetrieveController_Get_mthd {

//	  @GetMapping(method = RequestMethod.GET, value="/student/allstudent")
	 @RequestMapping(method = RequestMethod.GET, value="/student/allstudent")

	  @ResponseBody
	  public List<Student> getAllStudents() {
	  return StudentRegistration.getInstance().getStudentRecords();
	  }
}
